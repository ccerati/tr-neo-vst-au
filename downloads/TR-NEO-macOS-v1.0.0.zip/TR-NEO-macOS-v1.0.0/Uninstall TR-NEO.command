#!/bin/bash
# TR-NEO (тр-нео) — macOS Audio Unit & VST3 Uninstaller

set -euo pipefail

AU_DST="$HOME/Library/Audio/Plug-Ins/Components/TR-NEO.component"
VST3_DST="$HOME/Library/Audio/Plug-Ins/VST3/TR-NEO.vst3"

echo ""
echo "========================================================"
echo "  TR-NEO (тр-нео) // macOS AU + VST3 Uninstaller"
echo "========================================================"
echo ""

rm -rf "$AU_DST" "$VST3_DST"
killall -9 AudioComponentRegistrar 2>/dev/null || true

echo "Removed TR-NEO Audio Unit and VST3 from ~/Library/Audio/Plug-Ins/."
echo ""
read -r -p "Press Return to close..."
