TR-NEO (тр-нео) v1.0.0 — macOS AU + VST3 Analog Drum Machine
============================================================

Included in this package (Universal Binary: Apple Silicon + Intel):
  - TR-NEO.component          (macOS Audio Unit / AUv2)
  - TR-NEO.vst3               (macOS VST3)
  - Install TR-NEO.command    (Automated one-step installer)
  - Uninstall TR-NEO.command  (Clean uninstaller)

Requirements:
  - macOS 13 Ventura or newer (Apple Silicon M-series or Intel Mac)
  - Any AU or VST3 DAW (Ableton Live, Logic Pro, Bitwig, Reaper, Cubase, FL Studio, etc.)

--------------------------------------------------------
QUICK INSTALL (RECOMMENDED)
--------------------------------------------------------
1. Unzip this archive completely (do not run from inside the ZIP preview).
2. Double-click or Right-Click -> Open on "Install TR-NEO.command".
   (Because TR-NEO is an indie open release without paid Apple notarization,
   macOS Gatekeeper may ask you to confirm:
     - Click "Open" if prompted, OR
     - On macOS 15 Sequoia and newer, go to System Settings -> Privacy & Security,
       scroll down to "Install TR-NEO.command was blocked", and click "Open Anyway".)
3. The installer copies both plugins into ~/Library/Audio/Plug-Ins/, removes
   the download quarantine flag, and refreshes the macOS Audio Unit cache.
4. Restart your DAW and rescan plugins.

--------------------------------------------------------
MANUAL INSTALL (TERMINAL ALTERNATIVE)
--------------------------------------------------------
If you prefer installing manually from Terminal inside this extracted folder:

  mkdir -p ~/Library/Audio/Plug-Ins/Components ~/Library/Audio/Plug-Ins/VST3
  cp -R TR-NEO.component ~/Library/Audio/Plug-Ins/Components/
  cp -R TR-NEO.vst3 ~/Library/Audio/Plug-Ins/VST3/
  xattr -cr ~/Library/Audio/Plug-Ins/Components/TR-NEO.component ~/Library/Audio/Plug-Ins/VST3/TR-NEO.vst3
  killall -9 AudioComponentRegistrar 2>/dev/null || true

--------------------------------------------------------
DAW TIPS
--------------------------------------------------------
- Transport & Timing: TR-NEO loads ARMED in Host Sync mode so its 8-lane
  sequencer (1–16 steps, 4-way TR-606 SCALE, LINKED or POLY per-voice lengths,
  A / B / A->B / FILL slots) locks to Beat 1 when your DAW plays. Click STOP to
  trigger TR-NEO purely from DAW MIDI clips or drum pads (GM drum note map).
- Multi-Output Routing (9 x 2 Stereo):
  * Bus 0: Main Stereo (through PUNCH -> DRIVE Master Bus)
  * Buses 1–8: Individual stereo Aux outputs (BD, SD, LT, HT, CP, CY, OH, CH)
  * Click the routing chip on any mixer strip (AUTO / MAIN / AUX) to choose
    whether a voice routes automatically when an Aux bus is connected, stays on
    Main, or splits exclusively to its Aux bus.
- Live Performance Controls:
  * Hold 1/8, 1/16, or 1/32 ROLL for sample-accurate clock-locked note repeats
    on the selected voice.
  * Press FILL NOW while playing to fire Slot FILL immediately, or set Auto-Fill
    to 4B / 8B / 16B.
  * Solo always overrides Mute (pro console behavior).
- MIDI Out:
  * VST3 emits sequencer & note-roll MIDI directly to other tracks in DAWs that
    support VST3 MIDI Out (Ableton Live, Bitwig, Reaper, etc.).
  * AU users (or anyone routing to external gear) can toggle "MIDI PORT: ON" in
    the bottom-right footer to publish the "TR-NEO MIDI Out" CoreMIDI port.
