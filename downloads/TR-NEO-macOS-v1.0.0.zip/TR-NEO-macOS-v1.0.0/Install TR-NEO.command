#!/bin/bash
# TR-NEO (тр-нео) — Automated macOS Audio Unit & VST3 Installer
# Installs TR-NEO.component (AU) and TR-NEO.vst3 (VST3) for the current user,
# removes the macOS web-download quarantine flag, and refreshes the AU cache.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
AU_SRC="$SCRIPT_DIR/TR-NEO.component"
VST3_SRC="$SCRIPT_DIR/TR-NEO.vst3"

AU_DIR="$HOME/Library/Audio/Plug-Ins/Components"
VST3_DIR="$HOME/Library/Audio/Plug-Ins/VST3"

echo ""
echo "========================================================"
echo "  TR-NEO (тр-нео) // macOS AU + VST3 Installer"
echo "========================================================"
echo ""

if [ ! -d "$AU_SRC" ] || [ ! -d "$VST3_SRC" ]; then
  echo "ERROR: Could not find TR-NEO.component and TR-NEO.vst3 next to this installer."
  echo "Make sure you extracted the entire ZIP archive before running this script."
  echo ""
  read -r -p "Press Return to close..."
  exit 1
fi

mkdir -p "$AU_DIR" "$VST3_DIR"

echo "1/4  Installing Audio Unit (AU) -> $AU_DIR/TR-NEO.component"
rm -rf "$AU_DIR/TR-NEO.component"
cp -R "$AU_SRC" "$AU_DIR/TR-NEO.component"

echo "2/4  Installing VST3           -> $VST3_DIR/TR-NEO.vst3"
rm -rf "$VST3_DIR/TR-NEO.vst3"
cp -R "$VST3_SRC" "$VST3_DIR/TR-NEO.vst3"

echo "3/4  Clearing macOS Gatekeeper quarantine attributes..."
xattr -cr "$AU_DIR/TR-NEO.component" 2>/dev/null || true
xattr -cr "$VST3_DIR/TR-NEO.vst3" 2>/dev/null || true

echo "4/4  Refreshing macOS Audio Unit cache..."
killall -9 AudioComponentRegistrar 2>/dev/null || true

echo ""
echo "DONE! TR-NEO is installed:"
echo "  • AU   : $AU_DIR/TR-NEO.component"
echo "  • VST3 : $VST3_DIR/TR-NEO.vst3"
echo ""
echo "Restart your DAW (Ableton Live, Logic Pro, Reaper, Bitwig, Cubase, etc.) and rescan plugins."
echo "Note: TR-NEO exposes 9 stereo outputs (Main + 8 individual drum Aux outs)."
echo "For AU MIDI Out to other tracks, toggle 'MIDI PORT: ON' in the footer to use 'TR-NEO MIDI Out'."
echo ""
read -r -p "Press Return to close..."
